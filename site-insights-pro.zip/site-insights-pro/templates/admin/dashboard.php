<?php
/**
 * Admin Dashboard Template.
 *
 * @package SIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap sip-wrap" id="sip-dashboard" x-data="sipDashboard()" x-init="init()">

	<div class="sip-header">
		<div class="sip-header__brand">
			<svg class="sip-logo" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
				<rect width="32" height="32" rx="8" fill="var(--sip-accent)"/>
				<path d="M8 22 L12 14 L17 18 L21 10 L24 14" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
				<circle cx="24" cy="10" r="2" fill="white"/>
			</svg>
			<h1><?php esc_html_e( 'Site Insights Pro', 'site-insights-pro' ); ?></h1>
		</div>
		<div class="sip-header__actions">
			<select x-model="period" @change="loadAll()" class="sip-select">
				<option value="7"><?php esc_html_e( 'Last 7 days', 'site-insights-pro' ); ?></option>
				<option value="30" selected><?php esc_html_e( 'Last 30 days', 'site-insights-pro' ); ?></option>
				<option value="90"><?php esc_html_e( 'Last 90 days', 'site-insights-pro' ); ?></option>
				<option value="365"><?php esc_html_e( 'Last year', 'site-insights-pro' ); ?></option>
			</select>
			<button @click="loadAll()" class="sip-btn sip-btn--icon" :class="{ 'sip-btn--loading': loading }" title="<?php esc_attr_e( 'Refresh', 'site-insights-pro' ); ?>">
				<svg viewBox="0 0 20 20" fill="currentColor" class="sip-icon" :class="{ 'sip-spin': loading }"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
			</button>
		</div>
	</div>

	<!-- KPI Cards -->
	<div class="sip-kpi-grid">
		<div class="sip-kpi-card">
			<div class="sip-kpi-card__icon sip-kpi-card__icon--visitors">
				<svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"/></svg>
			</div>
			<div class="sip-kpi-card__content">
				<span class="sip-kpi-card__label"><?php esc_html_e( "Today's Visitors", 'site-insights-pro' ); ?></span>
				<span class="sip-kpi-card__value" x-text="fmt(summary.visitors?.today)">—</span>
			</div>
		</div>

		<div class="sip-kpi-card">
			<div class="sip-kpi-card__icon sip-kpi-card__icon--views">
				<svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10z" clip-rule="evenodd"/></svg>
			</div>
			<div class="sip-kpi-card__content">
				<span class="sip-kpi-card__label"><?php esc_html_e( 'Page Views Today', 'site-insights-pro' ); ?></span>
				<span class="sip-kpi-card__value" x-text="fmt(summary.page_views_today)">—</span>
			</div>
		</div>

		<div class="sip-kpi-card">
			<div class="sip-kpi-card__icon sip-kpi-card__icon--sessions">
				<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 5a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-2.22l.123.489.804.804A1 1 0 0113 18H7a1 1 0 01-.707-1.707l.804-.804L7.22 15H5a2 2 0 01-2-2V5zm5.771 7H5V5h10v7H8.771z" clip-rule="evenodd"/></svg>
			</div>
			<div class="sip-kpi-card__content">
				<span class="sip-kpi-card__label"><?php esc_html_e( 'Total Sessions', 'site-insights-pro' ); ?></span>
				<span class="sip-kpi-card__value" x-text="fmt(summary.sessions)">—</span>
			</div>
		</div>

		<div class="sip-kpi-card">
			<div class="sip-kpi-card__icon sip-kpi-card__icon--duration">
				<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
			</div>
			<div class="sip-kpi-card__content">
				<span class="sip-kpi-card__label"><?php esc_html_e( 'Avg. Session Duration', 'site-insights-pro' ); ?></span>
				<span class="sip-kpi-card__value" x-text="fmtDuration(summary.avg_duration)">—</span>
			</div>
		</div>

		<div class="sip-kpi-card">
			<div class="sip-kpi-card__icon sip-kpi-card__icon--users">
				<svg viewBox="0 0 20 20" fill="currentColor"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"/></svg>
			</div>
			<div class="sip-kpi-card__content">
				<span class="sip-kpi-card__label"><?php esc_html_e( 'Total Users', 'site-insights-pro' ); ?></span>
				<span class="sip-kpi-card__value" x-text="fmt(summary.users?.total)">—</span>
			</div>
		</div>

		<div class="sip-kpi-card">
			<div class="sip-kpi-card__icon sip-kpi-card__icon--comments">
				<svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 5a2 2 0 012-2h7a2 2 0 012 2v4a2 2 0 01-2 2H9l-3 3v-3H4a2 2 0 01-2-2V5z"/><path d="M15 7v2a4 4 0 01-4 4H9.828l-1.766 1.767c.28.149.599.233.938.233h2l3 3v-3h2a2 2 0 002-2V9a2 2 0 00-2-2h-1z"/></svg>
			</div>
			<div class="sip-kpi-card__content">
				<span class="sip-kpi-card__label"><?php esc_html_e( 'Total Comments', 'site-insights-pro' ); ?></span>
				<span class="sip-kpi-card__value" x-text="fmt(summary.comments)">—</span>
			</div>
		</div>
	</div><!-- /.sip-kpi-grid -->

	<!-- Charts Row 1: Visitors Trend + Device Doughnut -->
	<div class="sip-charts-row">
		<div class="sip-card sip-card--wide">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Visitor Trend', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body">
				<canvas id="chartVisitors" height="110"></canvas>
			</div>
		</div>

		<div class="sip-card">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Devices', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body sip-card__body--center">
				<canvas id="chartDevices" height="220"></canvas>
			</div>
		</div>
	</div>

	<!-- Charts Row 2: Top Pages + Browsers -->
	<div class="sip-charts-row">
		<div class="sip-card sip-card--wide">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Top Pages', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body">
				<canvas id="chartPages" height="140"></canvas>
			</div>
		</div>

		<div class="sip-card">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Browsers', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body sip-card__body--center">
				<canvas id="chartBrowsers" height="220"></canvas>
			</div>
		</div>
	</div>

	<!-- Charts Row 3: Weekly Activity + User Growth -->
	<div class="sip-charts-row">
		<div class="sip-card">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Weekday Activity', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body">
				<canvas id="chartWeekly" height="180"></canvas>
			</div>
		</div>

		<div class="sip-card sip-card--wide">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'User Growth', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body">
				<canvas id="chartUsers" height="180"></canvas>
			</div>
		</div>
	</div>

	<!-- Heatmap -->
	<div class="sip-card sip-card--full">
		<div class="sip-card__header">
			<h2><?php esc_html_e( 'Peak Traffic Hours', 'site-insights-pro' ); ?></h2>
		</div>
		<div class="sip-card__body">
			<div id="sip-heatmap" class="sip-heatmap" x-html="heatmapHtml"></div>
		</div>
	</div>

	<!-- Geographic + Most Commented -->
	<div class="sip-charts-row">
		<div class="sip-card">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Top Countries', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body">
				<ul class="sip-country-list">
					<template x-for="row in countries" :key="row.country">
						<li class="sip-country-list__item">
							<span class="sip-country-list__flag" x-text="countryFlag(row.country)"></span>
							<span class="sip-country-list__name" x-text="row.country"></span>
							<div class="sip-country-list__bar-wrap">
								<div class="sip-country-list__bar"
									:style="`width:${(row.total/countries[0].total*100).toFixed(1)}%`"></div>
							</div>
							<span class="sip-country-list__count" x-text="fmt(row.total)"></span>
						</li>
					</template>
					<li x-show="!countries.length" class="sip-empty"><?php esc_html_e( 'No geographic data yet.', 'site-insights-pro' ); ?></li>
				</ul>
			</div>
		</div>

		<div class="sip-card sip-card--wide">
			<div class="sip-card__header">
				<h2><?php esc_html_e( 'Most Commented Posts', 'site-insights-pro' ); ?></h2>
			</div>
			<div class="sip-card__body">
				<canvas id="chartComments" height="180"></canvas>
			</div>
		</div>
	</div>

	<!-- User stats strip -->
	<div class="sip-user-strip">
		<div class="sip-user-strip__item">
			<span class="sip-user-strip__label"><?php esc_html_e( 'New Today', 'site-insights-pro' ); ?></span>
			<span class="sip-user-strip__value" x-text="fmt(summary.users?.new_today)">—</span>
		</div>
		<div class="sip-user-strip__item">
			<span class="sip-user-strip__label"><?php esc_html_e( 'New This Week', 'site-insights-pro' ); ?></span>
			<span class="sip-user-strip__value" x-text="fmt(summary.users?.new_week)">—</span>
		</div>
		<div class="sip-user-strip__item">
			<span class="sip-user-strip__label"><?php esc_html_e( 'New This Month', 'site-insights-pro' ); ?></span>
			<span class="sip-user-strip__value" x-text="fmt(summary.users?.new_month)">—</span>
		</div>
		<div class="sip-user-strip__item">
			<span class="sip-user-strip__label"><?php esc_html_e( 'Weekly Visitors', 'site-insights-pro' ); ?></span>
			<span class="sip-user-strip__value" x-text="fmt(summary.visitors?.weekly)">—</span>
		</div>
		<div class="sip-user-strip__item">
			<span class="sip-user-strip__label"><?php esc_html_e( 'Monthly Visitors', 'site-insights-pro' ); ?></span>
			<span class="sip-user-strip__value" x-text="fmt(summary.visitors?.monthly)">—</span>
		</div>
		<div class="sip-user-strip__item">
			<span class="sip-user-strip__label"><?php esc_html_e( 'Avg Pages/Session', 'site-insights-pro' ); ?></span>
			<span class="sip-user-strip__value" x-text="summary.avg_pages_session ?? '—'">—</span>
		</div>
	</div>

</div><!-- /#sip-dashboard -->
