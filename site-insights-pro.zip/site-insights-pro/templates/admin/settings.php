<?php
/**
 * Admin Settings Template.
 *
 * @package SIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $_POST['submit'] ) ) {
	check_admin_referer( 'sip_settings_group-options' );
}
?>
<div class="wrap sip-settings-wrap">
	<h1><?php esc_html_e( 'Site Insights Pro — Settings', 'site-insights-pro' ); ?></h1>
	<form method="post" action="options.php">
		<?php
		settings_fields( 'sip_settings_group' );
		do_settings_sections( 'sip_settings_group' );
		submit_button();
		?>
	</form>
</div>
