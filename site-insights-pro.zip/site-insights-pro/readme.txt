=== Site Insights Pro ===
Contributors: yourname
Tags: analytics, statistics, visitors, tracking, dashboard
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A production-ready, privacy-first analytics plugin with a beautiful Alpine.js + Chart.js dashboard.

== Description ==

Site Insights Pro gives WordPress site owners deep analytics without sending data to third-party servers.

= Features =
* Visitor analytics — today, weekly, monthly, total, unique
* Browsing analytics — page views, session duration, pages/session
* User analytics — registrations, growth trends
* Content analytics — top pages, most-commented posts
* Geographic analytics — country/city breakdown (pluggable GeoIP)
* Device & browser analytics
* Performance insights — peak hours heatmap, weekday activity
* Beautiful Chart.js dashboard (line, bar, doughnut, pie, heatmap)
* Alpine.js reactive UI — no page reloads
* GDPR-friendly — IP anonymization built-in
* Multisite compatible
* Translation ready

= Shortcode =
Display a read-only summary dashboard on any page/post:

    [site_insights_dashboard]

Options:
    capability="manage_options"  — who can see it (default: admins only)
    theme="light"                — "light" or "dark"

= Technical =
* Custom DB tables with indexed aggregates
* Asynchronous REST tracking — zero impact on page speed
* WP-Cron nightly aggregation
* Transient caching on all dashboard queries
* Rate limiting on the tracking endpoint
* PSR-4 autoloading under the SIP namespace

== Installation ==
1. Upload `site-insights-pro` to `/wp-content/plugins/`
2. Activate through **Plugins → Installed Plugins**
3. Visit **Site Insights** in the admin sidebar

== Frequently Asked Questions ==

= Does it track logged-in admins? =
No — by default administrators are excluded. You can change this in **Settings**.

= Is it GDPR compliant? =
IP addresses are never stored in plain text. Enable **Anonymize IPs** in Settings to zero the last octet before hashing.

= Can I add my own GeoIP provider? =
Yes. Hook into `sip_geoip_lookup` to supply country/city from MaxMind GeoLite2 or any other source.

== Hooks & Filters ==

    // Disable tracking on certain pages
    add_filter( 'sip_enable_tracking', '__return_false' );

    // Provide real GeoIP data via MaxMind or similar
    add_filter( 'sip_geoip_lookup', function( $default, $ip ) {
        // return ['country' => 'NL', 'city' => 'Amsterdam'];
    }, 10, 2 );

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
First release.
