<?php
/**
 * Direct-access guard for include files.
 * Place at the top of every file in includes/ that is not a class file.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct access not permitted.' );
}
