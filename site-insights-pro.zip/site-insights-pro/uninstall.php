<?php
/**
 * Uninstall handler — runs when the plugin is deleted from the WordPress admin.
 *
 * @package SIP
 */

// Security: only run via WP uninstall mechanism.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/src/Database/Installer.php';

if ( is_multisite() ) {
	foreach ( get_sites( [ 'fields' => 'ids' ] ) as $blog_id ) {
		switch_to_blog( $blog_id );
		\SIP\Database\Installer::uninstall();
		restore_current_blog();
	}
} else {
	\SIP\Database\Installer::uninstall();
}
