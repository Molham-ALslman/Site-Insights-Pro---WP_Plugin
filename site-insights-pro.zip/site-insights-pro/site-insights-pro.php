<?php
/**
 * Plugin Name:       Site Insights Pro
 * Plugin URI:        https://example.com/site-insights-pro
 * Description:       A comprehensive analytics plugin for WordPress with visitor, content, geographic, device, and performance insights.
 * Version:           2.1.1
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Molham Alslman
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       site-insights-pro
 * Domain Path:       /languages
 * Network:           true
 */

declare(strict_types=1);

namespace SIP;

// Prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'SIP_VERSION', '1.0.0' );
define( 'SIP_PLUGIN_FILE', __FILE__ );
define( 'SIP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SIP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SIP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'SIP_DB_VERSION', '1.0.0' );
define( 'SIP_MIN_PHP', '8.0' );
define( 'SIP_MIN_WP', '6.0' );

/**
 * Autoloader for SIP namespace classes.
 */
spl_autoload_register( function ( string $class ): void {
	$prefix   = 'SIP\\';
	$base_dir = SIP_PLUGIN_DIR . 'src/';

	if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) {
		return;
	}

	$relative_class = substr( $class, strlen( $prefix ) );
	$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

	if ( file_exists( $file ) ) {
		require $file;
	}
} );

/**
 * Check system requirements before initializing.
 */
function sip_check_requirements(): bool {
	if ( version_compare( PHP_VERSION, SIP_MIN_PHP, '<' ) ) {
		add_action( 'admin_notices', function () {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: Required PHP version, 2: Current PHP version */
						__( 'Site Insights Pro requires PHP %1$s or higher. You are running PHP %2$s.', 'site-insights-pro' ),
						SIP_MIN_PHP,
						PHP_VERSION
					)
				)
			);
		} );
		return false;
	}

	global $wp_version;
	if ( version_compare( $wp_version, SIP_MIN_WP, '<' ) ) {
		add_action( 'admin_notices', function () use ( $wp_version ) {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: Required WP version, 2: Current WP version */
						__( 'Site Insights Pro requires WordPress %1$s or higher. You are running WordPress %2$s.', 'site-insights-pro' ),
						SIP_MIN_WP,
						$wp_version
					)
				)
			);
		} );
		return false;
	}

	return true;
}

/**
 * Initialize the plugin.
 */
function sip_init(): void {
	if ( ! sip_check_requirements() ) {
		return;
	}

	// Load translations.
	load_plugin_textdomain( 'site-insights-pro', false, dirname( SIP_PLUGIN_BASENAME ) . '/languages' );

	// Bootstrap the main plugin class.
	Plugin::get_instance();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\\sip_init' );

/**
 * Activation hook.
 */
register_activation_hook( __FILE__, function ( bool $network_wide ): void {
	require_once SIP_PLUGIN_DIR . 'src/Database/Installer.php';
	if ( $network_wide && is_multisite() ) {
		foreach ( get_sites( [ 'fields' => 'ids' ] ) as $blog_id ) {
			switch_to_blog( $blog_id );
			Database\Installer::install();
			restore_current_blog();
		}
	} else {
		Database\Installer::install();
	}
	Cron\Scheduler::register();
} );

/**
 * Deactivation hook.
 */
register_deactivation_hook( __FILE__, function (): void {
	Cron\Scheduler::deregister();
} );