<?php
/**
 * Main Plugin orchestrator.
 *
 * @package SIP
 */

declare(strict_types=1);

namespace SIP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static ?Plugin $instance = null;

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->register_services();
	}

	private function register_services(): void {
		// Core services.
		new Database\Installer();
		new Cron\Scheduler();

		// Tracking beacon JS — only on frontend pages where needed.
		if ( ! $this->should_skip_tracking() ) {
			new Analytics\TrackingEngine();
		}

		// REST API — always active (tracking endpoint + dashboard data).
		new Api\RestController();

		// Admin UI.
		if ( is_admin() ) {
			new Admin\DashboardController();
			new Admin\SettingsController();
		}

		// Shortcodes.
		new Shortcodes\InsightsDashboard();

		// Multisite.
		add_action( 'wpmu_new_blog', [ $this, 'on_new_blog' ] );
	}

	/**
	 * Should the frontend tracking beacon (tracker.js) be skipped?
	 *
	 * This only controls whether the JS file is enqueued on the page.
	 * The REST endpoint that writes events to the DB is always active.
	 */
	private function should_skip_tracking(): bool {
		// Never enqueue inside wp-admin.
		if ( is_admin() ) {
			return true;
		}

		// Skip during WP-Cron.
		if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
			return true;
		}

		// For administrators: check the plugin setting.
		// Default = true (admins skipped). Disable in Settings > Site Insights.
		if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			$settings = get_option( 'sip_settings', [] );
			return isset( $settings['skip_admin_tracking'] )
				? (bool) $settings['skip_admin_tracking']
				: true;
		}

		// Track all other visitors (guests + regular users).
		return false;
	}

	public function on_new_blog( int $blog_id ): void {
		switch_to_blog( $blog_id );
		Database\Installer::install();
		restore_current_blog();
	}
}
