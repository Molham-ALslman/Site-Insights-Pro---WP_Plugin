<?php
/**
 * REST API Controller.
 *
 * @package SIP\Api
 */

declare(strict_types=1);

namespace SIP\Api;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use SIP\Analytics\ChartDataProvider;
use SIP\Services\DeviceDetector;
use SIP\Services\GeoIpService;

/**
 * Registers all REST API routes for Site Insights Pro.
 */
class RestController {

	private const NAMESPACE = 'sip/v1';
	private const RATE_LIMIT = 60; // requests per minute per IP.

	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function register_routes(): void {
		// ----- Tracking endpoint (public, rate-limited) ----- //
		register_rest_route( self::NAMESPACE, '/track', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_track' ],
			'permission_callback' => [ $this, 'check_track_permission' ],
			'args'                => [
				'url'        => [ 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ],
				'referrer'   => [ 'type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'required' => false ],
				'session_id' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
				'visitor_id' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
				'object_id'  => [ 'type' => 'integer', 'required' => false ],
				'post_type'  => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'required' => false ],
			],
		] );

		// ----- Analytics data endpoints (admin only) ----- //
		$auth = [ $this, 'check_admin_permission' ];

		register_rest_route( self::NAMESPACE, '/summary', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_summary' ],
			'permission_callback' => $auth,
		] );

		register_rest_route( self::NAMESPACE, '/chart/visitors', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_visitor_chart' ],
			'permission_callback' => $auth,
			'args'                => [
				'days' => [ 'type' => 'integer', 'default' => 30, 'minimum' => 7, 'maximum' => 365 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/chart/pages', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_pages_chart' ],
			'permission_callback' => $auth,
			'args'                => [
				'limit' => [ 'type' => 'integer', 'default' => 10, 'minimum' => 5, 'maximum' => 25 ],
				'days'  => [ 'type' => 'integer', 'default' => 30, 'minimum' => 7, 'maximum' => 365 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/chart/devices', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_devices_chart' ],
			'permission_callback' => $auth,
			'args'                => [
				'days' => [ 'type' => 'integer', 'default' => 30 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/chart/browsers', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_browsers_chart' ],
			'permission_callback' => $auth,
			'args'                => [
				'days' => [ 'type' => 'integer', 'default' => 30 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/chart/heatmap', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_heatmap' ],
			'permission_callback' => $auth,
			'args'                => [
				'days' => [ 'type' => 'integer', 'default' => 30 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/chart/weekly', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_weekly_chart' ],
			'permission_callback' => $auth,
		] );

		register_rest_route( self::NAMESPACE, '/geo/countries', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_countries' ],
			'permission_callback' => $auth,
			'args'                => [
				'days'  => [ 'type' => 'integer', 'default' => 30 ],
				'limit' => [ 'type' => 'integer', 'default' => 10 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/geo/cities', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_cities' ],
			'permission_callback' => $auth,
		] );

		register_rest_route( self::NAMESPACE, '/users/growth', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_user_growth' ],
			'permission_callback' => $auth,
			'args'                => [
				'days' => [ 'type' => 'integer', 'default' => 30 ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/content/comments', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_most_commented' ],
			'permission_callback' => $auth,
		] );
	}

	// ------------------------------------------------------------------ //
	// Permission callbacks
	// ------------------------------------------------------------------ //

	public function check_admin_permission(): bool {
		return current_user_can( 'manage_options' );
	}

	public function check_track_permission( \WP_REST_Request $request ): bool {
		// Must have valid nonce.
		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return false;
		}

		// Rate limiting.
		$ip = $this->get_client_ip();
		if ( ! $this->check_rate_limit( $ip ) ) {
			return false;
		}

		return true;
	}

	// ------------------------------------------------------------------ //
	// Tracking handler
	// ------------------------------------------------------------------ //

	public function handle_track( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		$settings    = get_option( 'sip_settings', [] );
		$anonymize   = ! empty( $settings['anonymize_ip'] );
		$ip          = $this->get_client_ip();
		$ip_hash     = GeoIpService::hash( $anonymize ? GeoIpService::anonymize( $ip ) : $ip );

		$geo         = ( new GeoIpService() )->lookup( $ip );
		$detector    = new DeviceDetector();

		$data = [
			'session_id'  => sanitize_text_field( $request->get_param( 'session_id' ) ),
			'visitor_id'  => sanitize_text_field( $request->get_param( 'visitor_id' ) ),
			'user_id'     => get_current_user_id() ?: null,
			'object_id'   => $request->get_param( 'object_id' ) ?: null,
			'object_type' => sanitize_text_field( $request->get_param( 'post_type' ) ?: '' ),
			'url'         => esc_url_raw( $request->get_param( 'url' ) ?: '' ),
			'referrer'    => esc_url_raw( $request->get_param( 'referrer' ) ?: '' ),
			'ip_hash'     => $ip_hash,
			'country'     => $geo['country'],
			'city'        => $geo['city'],
			'device_type' => $detector->get_device_type(),
			'os'          => $detector->get_os(),
			'browser'     => $detector->get_browser(),
			'created_at'  => current_time( 'mysql', true ),
		];

		$wpdb->insert( "{$wpdb->prefix}sip_events", $data );

		return new \WP_REST_Response( [ 'success' => true ], 201 );
	}

	// ------------------------------------------------------------------ //
	// Data endpoints — wrapped in try/catch for debugging
	// ------------------------------------------------------------------ //

	private function safe_response( callable $fn ): \WP_REST_Response {
		try {
			return rest_ensure_response( $fn() );
		} catch ( \Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				return new \WP_REST_Response(
					[ 'sip_error' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine() ],
					500
				);
			}
			return new \WP_REST_Response( [ 'sip_error' => 'Internal server error' ], 500 );
		}
	}

	public function get_summary(): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_summary() );
	}

	public function get_visitor_chart( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_visitor_trend( (int) $r->get_param( 'days' ) ) );
	}

	public function get_pages_chart( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response(
			fn() => ( new ChartDataProvider() )->get_top_pages( (int) $r->get_param( 'limit' ), (int) $r->get_param( 'days' ) )
		);
	}

	public function get_devices_chart( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_device_distribution( (int) $r->get_param( 'days' ) ) );
	}

	public function get_browsers_chart( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_browser_distribution( (int) $r->get_param( 'days' ) ) );
	}

	public function get_heatmap( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_hourly_heatmap( (int) $r->get_param( 'days' ) ) );
	}

	public function get_weekly_chart(): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_weekly_activity() );
	}

	public function get_countries( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response(
			fn() => ( new ChartDataProvider() )->get_top_countries( (int) $r->get_param( 'limit' ),
				(int) $r->get_param( 'days' ) )
		);
	}

	public function get_cities(): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_top_cities() );
	}

	public function get_user_growth( \WP_REST_Request $r ): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_user_growth( (int) $r->get_param( 'days' ) ) );
	}

	public function get_most_commented(): \WP_REST_Response {
		return $this->safe_response( fn() => ( new ChartDataProvider() )->get_most_commented() );
	}

	// ------------------------------------------------------------------ //
	// Helpers
	// ------------------------------------------------------------------ //

	private function get_client_ip(): string {
		$headers = [
			'HTTP_CF_CONNECTING_IP',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_REAL_IP',
			'REMOTE_ADDR',
		];
		foreach ( $headers as $header ) {
			if ( ! empty( $_SERVER[ $header ] ) ) {
				$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) ) )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		return '0.0.0.0';
	}

	private function check_rate_limit( string $ip ): bool {
		global $wpdb;

		$ip_hash = GeoIpService::hash( $ip );
		$now     = current_time( 'mysql', true );
		$table   = "{$wpdb->prefix}sip_rate_limits";

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE ip_hash = %s", $ip_hash )
		);

		if ( ! $row ) {
			$wpdb->insert( $table, [
				'ip_hash'    => $ip_hash,
				'requests'   => 1,
				'window_end' => gmdate( 'Y-m-d H:i:s', (int) strtotime( '+1 minute' ) ),
			] );
			return true;
		}

		if ( $now > $row->window_end ) {
			$wpdb->update(
				$table,
				[ 'requests' => 1, 'window_end' => gmdate( 'Y-m-d H:i:s', (int) strtotime( '+1 minute' ) ) ],
				[ 'ip_hash' => $ip_hash ]
			);
			return true;
		}

		if ( (int) $row->requests >= self::RATE_LIMIT ) {
			return false;
		}

		$wpdb->update(
			$table,
			[ 'requests' => (int) $row->requests + 1 ],
			[ 'ip_hash' => $ip_hash ]
		);

		return true;
	}
}
