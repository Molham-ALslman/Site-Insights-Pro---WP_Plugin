<?php
/**
 * GeoIP Service Abstraction.
 *
 * @package SIP\Services
 */

declare(strict_types=1);

namespace SIP\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves an IP address to country/city.
 * Ships with a no-op implementation; integrators can provide a real backend
 * via the `sip_geoip_provider` filter (e.g. MaxMind GeoLite2).
 */
class GeoIpService {

	/**
	 * Look up geographic info for an IP address.
	 *
	 * @return array{country: string, city: string}
	 */
	public function lookup( string $ip ): array {
		/**
		 * Filter: sip_geoip_lookup
		 * Allows third-party code to supply real geo data.
		 *
		 * @param array  $default Default empty result.
		 * @param string $ip      The raw IP address.
		 */
		$result = apply_filters( 'sip_geoip_lookup', [ 'country' => '', 'city' => '' ], $ip );

		return [
			'country' => sanitize_text_field( $result['country'] ?? '' ),
			'city'    => sanitize_text_field( $result['city'] ?? '' ),
		];
	}

	/**
	 * Anonymize an IP address for GDPR compliance.
	 * IPv4: zero last octet. IPv6: zero last 80 bits.
	 */
	public static function anonymize( string $ip ): string {
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$parts = explode( ':', $ip );
			$parts = array_slice( $parts, 0, 4 );
			return implode( ':', $parts ) . ':0000:0000:0000:0000';
		}
		$parts    = explode( '.', $ip );
		$parts[3] = '0';
		return implode( '.', $parts );
	}

	/**
	 * Return a hashed representation of an IP (never store raw IPs).
	 */
	public static function hash( string $ip ): string {
		$salt = wp_salt( 'auth' );
		return hash_hmac( 'sha256', $ip, $salt );
	}
}
