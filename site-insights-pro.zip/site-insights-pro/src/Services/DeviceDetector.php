<?php
/**
 * Device Detection Service.
 *
 * @package SIP\Services
 */

declare(strict_types=1);

namespace SIP\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Detects device type, OS, and browser from a User-Agent string.
 * Pure PHP — no external dependencies.
 */
class DeviceDetector {

	private string $ua;

	public function __construct( string $user_agent = '' ) {
		$this->ua = $user_agent ?: ( $_SERVER['HTTP_USER_AGENT'] ?? '' );
	}

	public function get_device_type(): string {
		$ua = $this->ua;
		if ( preg_match( '/tablet|ipad|playbook|silk/i', $ua ) ) {
			return 'tablet';
		}
		if ( preg_match( '/mobile|android|iphone|ipod|blackberry|opera mini|iemobile|wpdesktop/i', $ua ) ) {
			return 'mobile';
		}
		return 'desktop';
	}

	public function get_os(): string {
		$map = [
			'Windows 11'    => 'Windows NT 10\.0.*rv:(9[2-9]|[1-9]\d{2})',
			'Windows 10'    => 'Windows NT 10\.0',
			'Windows 8.1'   => 'Windows NT 6\.3',
			'Windows 8'     => 'Windows NT 6\.2',
			'Windows 7'     => 'Windows NT 6\.1',
			'macOS'         => 'Macintosh.*Mac OS X',
			'iOS'           => '(iPhone|iPad|iPod)',
			'Android'       => 'Android',
			'Linux'         => 'Linux',
			'Chrome OS'     => 'CrOS',
		];
		foreach ( $map as $name => $pattern ) {
			if ( preg_match( "/{$pattern}/i", $this->ua ) ) {
				return $name;
			}
		}
		return 'Other';
	}

	public function get_browser(): string {
		$map = [
			'Edge'           => 'Edg/',
			'Chrome'         => 'Chrome/',
			'Firefox'        => 'Firefox/',
			'Safari'         => 'Safari/',
			'Opera'          => 'OPR/',
			'IE'             => 'Trident/',
			'Samsung Browser'=> 'SamsungBrowser/',
		];
		foreach ( $map as $name => $token ) {
			if ( str_contains( $this->ua, $token ) ) {
				return $name;
			}
		}
		return 'Other';
	}
}
