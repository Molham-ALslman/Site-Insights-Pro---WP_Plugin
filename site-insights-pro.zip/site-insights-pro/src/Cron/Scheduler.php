<?php
/**
 * Cron Scheduler.
 *
 * @package SIP\Cron
 */

declare(strict_types=1);

namespace SIP\Cron;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use SIP\Analytics\AggregationService;

/**
 * Registers and manages scheduled cron events.
 */
class Scheduler {

	private const DAILY_HOOK  = 'sip_daily_aggregation';
	private const CLEANUP_HOOK = 'sip_cleanup_rate_limits';

	public function __construct() {
		add_action( self::DAILY_HOOK,   [ $this, 'run_daily_aggregation' ] );
		add_action( self::CLEANUP_HOOK, [ $this, 'run_rate_limit_cleanup' ] );
	}

	/**
	 * Register scheduled events on plugin activation.
	 */
	public static function register(): void {
		if ( ! wp_next_scheduled( self::DAILY_HOOK ) ) {
			// Run at 00:05 server time each day.
			$midnight = strtotime( 'tomorrow midnight' ) + 5 * MINUTE_IN_SECONDS;
			wp_schedule_event( $midnight, 'daily', self::DAILY_HOOK );
		}

		if ( ! wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::CLEANUP_HOOK );
		}
	}

	/**
	 * Clear scheduled events on plugin deactivation.
	 */
	public static function deregister(): void {
		wp_clear_scheduled_hook( self::DAILY_HOOK );
		wp_clear_scheduled_hook( self::CLEANUP_HOOK );
	}

	/**
	 * Run daily aggregation (called by WP-Cron).
	 */
	public function run_daily_aggregation(): void {
		AggregationService::aggregate();
	}

	/**
	 * Purge expired rate-limit rows.
	 */
	public function run_rate_limit_cleanup(): void {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}sip_rate_limits WHERE window_end < %s",
				current_time( 'mysql', true )
			)
		);
	}
}
