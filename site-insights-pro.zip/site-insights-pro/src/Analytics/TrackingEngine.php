<?php
/**
 * Tracking Engine — injects the async tracking beacon.
 *
 * @package SIP\Analytics
 */

declare(strict_types=1);

namespace SIP\Analytics;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueues a tiny, deferred tracking script that fires an async REST request.
 * No synchronous database writes on the front end.
 */
class TrackingEngine {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_tracker' ] );
	}

	/**
	 * Enqueue the async tracking beacon.
	 */
	public function enqueue_tracker(): void {
		if ( ! apply_filters( 'sip_enable_tracking', true ) ) {
			return;
		}

		wp_enqueue_script(
			'sip-tracker',
			SIP_PLUGIN_URL . 'assets/js/tracker.js',
			[],
			SIP_VERSION,
			[ 'strategy' => 'defer', 'in_footer' => true ]
		);

		wp_localize_script(
			'sip-tracker',
			'sipTracker',
			[
				'endpoint' => esc_url_raw( rest_url( 'sip/v1/track' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'objectId' => get_queried_object_id(),
				'postType' => get_post_type() ?: '',
			]
		);
	}
}
