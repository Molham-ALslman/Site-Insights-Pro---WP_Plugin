<?php
/**
 * Data Aggregation Service.
 *
 * Summarises raw event rows into the pre-aggregated stat tables.
 *
 * @package SIP\Analytics
 */

declare(strict_types=1);

namespace SIP\Analytics;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles nightly aggregation of raw events into summary tables.
 */
class AggregationService {

	/**
	 * Run aggregation for a given date (YYYY-MM-DD). Defaults to yesterday.
	 */
	public static function aggregate( string $date = '' ): void {
		if ( empty( $date ) ) {
			$date = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		}

		self::aggregate_daily_stats( $date );
		self::aggregate_page_stats( $date );
		self::aggregate_geo_stats( $date );
		self::aggregate_device_stats( $date );
		self::aggregate_hourly_stats( $date );

		// Prune raw events older than 90 days (configurable).
		$settings     = get_option( 'sip_settings', [] );
		$retention    = absint( $settings['raw_event_retention_days'] ?? 90 );
		self::prune_raw_events( $retention );
	}

	// ------------------------------------------------------------------ //

	private static function aggregate_daily_stats( string $date ): void {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->prefix}sip_daily_stats
					(stat_date, visitors, unique_visitors, sessions, page_views, new_users, total_duration)
				SELECT
					%s                       AS stat_date,
					COUNT(*)                 AS visitors,
					COUNT(DISTINCT visitor_id) AS unique_visitors,
					COUNT(DISTINCT session_id) AS sessions,
					COUNT(*)                 AS page_views,
					0                        AS new_users,
					0                        AS total_duration
				FROM {$wpdb->prefix}sip_events
				WHERE DATE(created_at) = %s
				ON DUPLICATE KEY UPDATE
					visitors        = VALUES(visitors),
					unique_visitors = VALUES(unique_visitors),
					sessions        = VALUES(sessions),
					page_views      = VALUES(page_views)",
				$date,
				$date
			)
		);

		// Count new registered users for that day.
		$new_users = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}users WHERE DATE(user_registered) = %s",
				$date
			)
		);

		$wpdb->update(
			"{$wpdb->prefix}sip_daily_stats",
			[ 'new_users' => $new_users ],
			[ 'stat_date' => $date ],
			[ '%d' ],
			[ '%s' ]
		);
	}

	private static function aggregate_page_stats( string $date ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT object_id, url, COUNT(*) AS views
				FROM {$wpdb->prefix}sip_events
				WHERE DATE(created_at) = %s
				GROUP BY object_id, url",
				$date
			),
			ARRAY_A
		);

		foreach ( $rows as $row ) {
			$title = '';
			if ( ! empty( $row['object_id'] ) ) {
				$post  = get_post( (int) $row['object_id'] );
				$title = $post ? $post->post_title : '';
			}

			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->prefix}sip_page_stats (stat_date, object_id, url, title, views)
					VALUES (%s, %d, %s, %s, %d)
					ON DUPLICATE KEY UPDATE views = VALUES(views), title = VALUES(title)",
					$date,
					(int) $row['object_id'],
					$row['url'],
					$title,
					(int) $row['views']
				)
			);
		}
	}

	private static function aggregate_geo_stats( string $date ): void {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT country, city, COUNT(DISTINCT visitor_id) AS visitors
				FROM {$wpdb->prefix}sip_events
				WHERE DATE(created_at) = %s AND country IS NOT NULL
				GROUP BY country, city",
				$date
			),
			ARRAY_A
		);

		foreach ( $rows as $row ) {
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->prefix}sip_geo_stats (stat_date, country, city, visitors)
					VALUES (%s, %s, %s, %d)
					ON DUPLICATE KEY UPDATE visitors = VALUES(visitors)",
					$date,
					$row['country'],
					(string) $row['city'],
					(int) $row['visitors']
				)
			);
		}
	}

	private static function aggregate_device_stats( string $date ): void {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT device_type, os, browser, COUNT(DISTINCT visitor_id) AS visitors
				FROM {$wpdb->prefix}sip_events
				WHERE DATE(created_at) = %s
				GROUP BY device_type, os, browser",
				$date
			),
			ARRAY_A
		);

		foreach ( $rows as $row ) {
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->prefix}sip_device_stats (stat_date, device_type, os, browser, visitors)
					VALUES (%s, %s, %s, %s, %d)
					ON DUPLICATE KEY UPDATE visitors = VALUES(visitors)",
					$date,
					(string) $row['device_type'],
					(string) $row['os'],
					(string) $row['browser'],
					(int) $row['visitors']
				)
			);
		}
	}

	private static function aggregate_hourly_stats( string $date ): void {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->prefix}sip_hourly_stats (stat_date, hour, page_views)
				SELECT %s, HOUR(created_at), COUNT(*) AS page_views
				FROM {$wpdb->prefix}sip_events
				WHERE DATE(created_at) = %s
				GROUP BY HOUR(created_at)
				ON DUPLICATE KEY UPDATE page_views = VALUES(page_views)",
				$date,
				$date
			)
		);
	}

	private static function prune_raw_events( int $days ): void {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}sip_events WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
				$days
			)
		);
	}
}
