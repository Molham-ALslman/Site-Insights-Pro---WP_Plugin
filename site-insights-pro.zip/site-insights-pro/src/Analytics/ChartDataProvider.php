<?php
/**
 * Chart Data Provider — compatible version.
 *
 * Avoids complex UNION ALL queries for maximum MySQL compatibility.
 * Reads today's data live from sip_events, historical from sip_daily_stats.
 *
 * @package SIP\Analytics
 */

declare(strict_types=1);

namespace SIP\Analytics;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ChartDataProvider {

	// ------------------------------------------------------------------ //
	// Helper: run a safe single-value query
	// ------------------------------------------------------------------ //

	private function get_int( string $sql, array $args = [] ): int {
		global $wpdb;
		if ( ! empty( $args ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$sql = $wpdb->prepare( $sql, ...$args );
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $sql );
	}

	private function get_results( string $sql, array $args = [] ): array {
		global $wpdb;
		if ( ! empty( $args ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$sql = $wpdb->prepare( $sql, ...$args );
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $sql, ARRAY_A ) ?: [];
	}

	// ------------------------------------------------------------------ //
	// Summary KPIs
	// ------------------------------------------------------------------ //

	public function get_summary(): array {
		$cache_key = 'sip_summary_' . gmdate( 'YmdHi', (int) ( floor( time() / 300 ) * 300 ) );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$week      = gmdate( 'Y-m-d', (int) strtotime( '-7 days' ) );
		$month     = gmdate( 'Y-m-d', (int) strtotime( '-30 days' ) );

		// ── TODAY (live from raw events) ──────────────────────────────── //
		$today_visitors = $this->get_int(
			"SELECT COUNT(DISTINCT visitor_id) FROM {$wpdb->prefix}sip_events WHERE DATE(created_at) = %s",
			[ $today ]
		);
		$today_sessions = $this->get_int(
			"SELECT COUNT(DISTINCT session_id) FROM {$wpdb->prefix}sip_events WHERE DATE(created_at) = %s",
			[ $today ]
		);
		$today_pv = $this->get_int(
			"SELECT COUNT(*) FROM {$wpdb->prefix}sip_events WHERE DATE(created_at) = %s",
			[ $today ]
		);

		// ── HISTORICAL (from aggregated table, excludes today) ────────── //
		$hist_weekly_v = $this->get_int(
			"SELECT COALESCE(SUM(visitors), 0) FROM {$wpdb->prefix}sip_daily_stats WHERE stat_date BETWEEN %s AND %s",
			[ $week, $yesterday ]
		);
		$hist_monthly_v = $this->get_int(
			"SELECT COALESCE(SUM(visitors), 0) FROM {$wpdb->prefix}sip_daily_stats WHERE stat_date BETWEEN %s AND %s",
			[ $month, $yesterday ]
		);
		$hist_total_v = $this->get_int(
			"SELECT COALESCE(SUM(visitors), 0) FROM {$wpdb->prefix}sip_daily_stats"
		);
		$hist_pv = $this->get_int(
			"SELECT COALESCE(SUM(page_views), 0) FROM {$wpdb->prefix}sip_daily_stats"
		);
		$hist_sessions = $this->get_int(
			"SELECT COALESCE(SUM(sessions), 0) FROM {$wpdb->prefix}sip_daily_stats"
		);

		// ── COMBINED ─────────────────────────────────────────────────── //
		$weekly_visitors  = $hist_weekly_v  + $today_visitors;
		$monthly_visitors = $hist_monthly_v + $today_visitors;
		$total_visitors   = $hist_total_v   + $today_visitors;
		$total_pv         = $hist_pv        + $today_pv;
		$total_sessions   = $hist_sessions  + $today_sessions;

		// ── AVG DURATION (last 7 days) ────────────────────────────────── //
		$avg_duration = 0;
		try {
			$avg_duration = (float) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT AVG(dur) FROM (
						SELECT session_id,
							TIMESTAMPDIFF(SECOND, MIN(created_at), MAX(created_at)) AS dur
						FROM {$wpdb->prefix}sip_events
						WHERE created_at >= %s
						GROUP BY session_id
						HAVING dur > 0
					) AS s",
					$week
				)
			);
		} catch ( \Exception $e ) {
			$avg_duration = 0;
		}

		// ── USERS (always live from wp_users) ────────────────────────── //
		$total_users = $this->get_int( "SELECT COUNT(*) FROM {$wpdb->prefix}users" );
		$new_today   = $this->get_int(
			"SELECT COUNT(*) FROM {$wpdb->prefix}users WHERE DATE(user_registered) = %s",
			[ $today ]
		);
		$new_week = $this->get_int(
			"SELECT COUNT(*) FROM {$wpdb->prefix}users WHERE DATE(user_registered) BETWEEN %s AND %s",
			[ $week, $today ]
		);
		$new_month = $this->get_int(
			"SELECT COUNT(*) FROM {$wpdb->prefix}users WHERE DATE(user_registered) BETWEEN %s AND %s",
			[ $month, $today ]
		);

		// ── COMMENTS ─────────────────────────────────────────────────── //
		$total_comments = $this->get_int(
			"SELECT COUNT(*) FROM {$wpdb->prefix}comments WHERE comment_approved = '1'"
		);

		$data = [
			'visitors' => [
				'today'   => $today_visitors,
				'weekly'  => $weekly_visitors,
				'monthly' => $monthly_visitors,
				'total'   => $total_visitors,
			],
			'sessions'          => $total_sessions,
			'sessions_today'    => $today_sessions,
			'page_views'        => $total_pv,
			'page_views_today'  => $today_pv,
			'avg_duration'      => (int) round( $avg_duration ),
			'avg_pages_session' => $total_sessions > 0
				? round( $total_pv / $total_sessions, 1 )
				: 0,
			'total_hours'       => $avg_duration > 0
				? round( $total_pv * ( $avg_duration / 3600 ), 1 )
				: 0,
			'users' => [
				'total'     => $total_users,
				'new_today' => $new_today,
				'new_week'  => $new_week,
				'new_month' => $new_month,
			],
			'comments' => $total_comments,
		];

		set_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
		return $data;
	}

	// ------------------------------------------------------------------ //
	// Visitor Trend — line chart
	// ------------------------------------------------------------------ //

	public function get_visitor_trend( int $days = 30 ): array {
		$cache_key = "sip_trend_{$days}_" . gmdate( 'YmdHi', (int) ( floor( time() / 300 ) * 300 ) );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$start     = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		// Historical rows from aggregated table.
		$rows = $this->get_results(
			"SELECT stat_date, visitors, unique_visitors
			 FROM {$wpdb->prefix}sip_daily_stats
			 WHERE stat_date BETWEEN %s AND %s
			 ORDER BY stat_date ASC",
			[ $start, $yesterday ]
		);

		// Append today live.
		$today_v = $this->get_int(
			"SELECT COUNT(DISTINCT visitor_id) FROM {$wpdb->prefix}sip_events WHERE DATE(created_at) = %s",
			[ $today ]
		);
		$rows[] = [
			'stat_date'       => $today,
			'visitors'        => $today_v,
			'unique_visitors' => $today_v,
		];

		$labels   = array_column( $rows, 'stat_date' );
		$visitors = array_map( 'intval', array_column( $rows, 'visitors' ) );
		$unique   = array_map( 'intval', array_column( $rows, 'unique_visitors' ) );

		$data = compact( 'labels', 'visitors', 'unique' );
		set_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
		return $data;
	}

	// ------------------------------------------------------------------ //
	// Top Pages — bar chart
	// ------------------------------------------------------------------ //

	public function get_top_pages( int $limit = 10, int $days = 30 ): array {
		$cache_key = "sip_pages_{$limit}_{$days}";
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$start     = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		// Historical from page_stats.
		$hist = $this->get_results(
			"SELECT url, title, SUM(views) AS total_views
			 FROM {$wpdb->prefix}sip_page_stats
			 WHERE stat_date BETWEEN %s AND %s
			 GROUP BY url, title
			 ORDER BY total_views DESC
			 LIMIT %d",
			[ $start, $yesterday, $limit ]
		);

		// Today live from raw events.
		$live = $this->get_results(
			"SELECT url, '' AS title, COUNT(*) AS total_views
			 FROM {$wpdb->prefix}sip_events
			 WHERE DATE(created_at) = %s
			 GROUP BY url
			 ORDER BY total_views DESC
			 LIMIT %d",
			[ $today, $limit ]
		);

		// Merge by url.
		$merged = [];
		foreach ( $hist as $r ) {
			$merged[ $r['url'] ] = [
				'url'         => $r['url'],
				'title'       => $r['title'],
				'total_views' => (int) $r['total_views'],
			];
		}
		foreach ( $live as $r ) {
			if ( isset( $merged[ $r['url'] ] ) ) {
				$merged[ $r['url'] ]['total_views'] += (int) $r['total_views'];
			} else {
				$merged[ $r['url'] ] = [
					'url'         => $r['url'],
					'title'       => '',
					'total_views' => (int) $r['total_views'],
				];
			}
		}

		// Sort and limit.
		usort( $merged, fn( $a, $b ) => $b['total_views'] - $a['total_views'] );
		$rows   = array_slice( $merged, 0, $limit );
		$labels = array_map( fn( $r ) => $r['title'] ?: $r['url'], $rows );
		$views  = array_map( fn( $r ) => $r['total_views'], $rows );

		$data = compact( 'labels', 'views', 'rows' );
		set_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
		return $data;
	}

	// ------------------------------------------------------------------ //
	// Device distribution — doughnut
	// ------------------------------------------------------------------ //

	public function get_device_distribution( int $days = 30 ): array {
		$cache_key = "sip_dev_{$days}";
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$start     = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		// Historical.
		$hist = $this->get_results(
			"SELECT device_type, SUM(visitors) AS total
			 FROM {$wpdb->prefix}sip_device_stats
			 WHERE stat_date BETWEEN %s AND %s
			 GROUP BY device_type",
			[ $start, $yesterday ]
		);

		// Today live.
		$live = $this->get_results(
			"SELECT device_type, COUNT(DISTINCT visitor_id) AS total
			 FROM {$wpdb->prefix}sip_events
			 WHERE DATE(created_at) = %s
			 GROUP BY device_type",
			[ $today ]
		);

		$merged = [];
		foreach ( $hist as $r ) {
			$merged[ $r['device_type'] ] = (int) $r['total'];
		}
		foreach ( $live as $r ) {
			$key = $r['device_type'] ?: 'desktop';
			$merged[ $key ] = ( $merged[ $key ] ?? 0 ) + (int) $r['total'];
		}

		arsort( $merged );
		$labels = array_map( 'ucfirst', array_keys( $merged ) );
		$data   = array_values( $merged );

		$result = compact( 'labels', 'data' );
		set_transient( $cache_key, $result, 5 * MINUTE_IN_SECONDS );
		return $result;
	}

	// ------------------------------------------------------------------ //
	// Browser distribution — pie
	// ------------------------------------------------------------------ //

	public function get_browser_distribution( int $days = 30 ): array {
		$cache_key = "sip_brow_{$days}";
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$start     = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		$hist = $this->get_results(
			"SELECT browser, SUM(visitors) AS total
			 FROM {$wpdb->prefix}sip_device_stats
			 WHERE stat_date BETWEEN %s AND %s AND browser != ''
			 GROUP BY browser",
			[ $start, $yesterday ]
		);

		$live = $this->get_results(
			"SELECT browser, COUNT(DISTINCT visitor_id) AS total
			 FROM {$wpdb->prefix}sip_events
			 WHERE DATE(created_at) = %s AND browser != ''
			 GROUP BY browser",
			[ $today ]
		);

		$merged = [];
		foreach ( $hist as $r ) {
			$merged[ $r['browser'] ] = (int) $r['total'];
		}
		foreach ( $live as $r ) {
			if ( ! empty( $r['browser'] ) ) {
				$merged[ $r['browser'] ] = ( $merged[ $r['browser'] ] ?? 0 ) + (int) $r['total'];
			}
		}

		arsort( $merged );
		$merged = array_slice( $merged, 0, 8, true );
		$labels = array_keys( $merged );
		$data   = array_values( $merged );

		$result = compact( 'labels', 'data' );
		set_transient( $cache_key, $result, 5 * MINUTE_IN_SECONDS );
		return $result;
	}

	// ------------------------------------------------------------------ //
	// Hourly heatmap
	// ------------------------------------------------------------------ //

	public function get_hourly_heatmap( int $days = 30 ): array {
		$cache_key = "sip_heat_{$days}";
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$start     = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		$hist = $this->get_results(
			"SELECT DAYOFWEEK(stat_date) - 1 AS weekday, hour, SUM(page_views) AS views
			 FROM {$wpdb->prefix}sip_hourly_stats
			 WHERE stat_date BETWEEN %s AND %s
			 GROUP BY weekday, hour",
			[ $start, $yesterday ]
		);

		$live = $this->get_results(
			"SELECT DAYOFWEEK(DATE(created_at)) - 1 AS weekday,
			        HOUR(created_at) AS hour,
			        COUNT(*) AS views
			 FROM {$wpdb->prefix}sip_events
			 WHERE DATE(created_at) = %s
			 GROUP BY weekday, hour",
			[ $today ]
		);

		$matrix = array_fill( 0, 7, array_fill( 0, 24, 0 ) );
		foreach ( array_merge( $hist, $live ) as $row ) {
			$d = (int) $row['weekday'];
			$h = (int) $row['hour'];
			if ( isset( $matrix[ $d ][ $h ] ) ) {
				$matrix[ $d ][ $h ] += (int) $row['views'];
			}
		}

		set_transient( $cache_key, $matrix, 5 * MINUTE_IN_SECONDS );
		return $matrix;
	}

	// ------------------------------------------------------------------ //
	// Geographic data
	// ------------------------------------------------------------------ //

	public function get_top_countries( int $limit = 10, int $days = 30 ): array {
		$cache_key = "sip_geo_{$limit}_{$days}";
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$today     = gmdate( 'Y-m-d' );
		$yesterday = gmdate( 'Y-m-d', (int) strtotime( '-1 day' ) );
		$start     = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		$hist = $this->get_results(
			"SELECT country, SUM(visitors) AS total
			 FROM {$wpdb->prefix}sip_geo_stats
			 WHERE stat_date BETWEEN %s AND %s AND country != ''
			 GROUP BY country",
			[ $start, $yesterday ]
		);

		$live = $this->get_results(
			"SELECT country, COUNT(DISTINCT visitor_id) AS total
			 FROM {$wpdb->prefix}sip_events
			 WHERE DATE(created_at) = %s AND country IS NOT NULL AND country != ''
			 GROUP BY country",
			[ $today ]
		);

		$merged = [];
		foreach ( $hist as $r ) {
			$merged[ $r['country'] ] = (int) $r['total'];
		}
		foreach ( $live as $r ) {
			if ( ! empty( $r['country'] ) ) {
				$merged[ $r['country'] ] = ( $merged[ $r['country'] ] ?? 0 ) + (int) $r['total'];
			}
		}

		arsort( $merged );
		$merged = array_slice( $merged, 0, $limit, true );

		$rows = [];
		foreach ( $merged as $country => $total ) {
			$rows[] = [ 'country' => $country, 'total' => $total ];
		}

		set_transient( $cache_key, $rows, 5 * MINUTE_IN_SECONDS );
		return $rows;
	}

	public function get_top_cities( int $limit = 10, int $days = 30 ): array {
		global $wpdb;
		$start = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		return $this->get_results(
			"SELECT city, country, SUM(visitors) AS total
			 FROM {$wpdb->prefix}sip_geo_stats
			 WHERE stat_date >= %s AND city != ''
			 GROUP BY city, country
			 ORDER BY total DESC
			 LIMIT %d",
			[ $start, $limit ]
		);
	}

	// ------------------------------------------------------------------ //
	// User growth
	// ------------------------------------------------------------------ //

	public function get_user_growth( int $days = 30 ): array {
		global $wpdb;
		$start = gmdate( 'Y-m-d', (int) strtotime( "-{$days} days" ) );

		$rows = $this->get_results(
			"SELECT DATE(user_registered) AS reg_date, COUNT(*) AS count
			 FROM {$wpdb->prefix}users
			 WHERE DATE(user_registered) >= %s
			 GROUP BY reg_date
			 ORDER BY reg_date ASC",
			[ $start ]
		);

		return [
			'labels' => array_column( $rows, 'reg_date' ),
			'data'   => array_map( 'intval', array_column( $rows, 'count' ) ),
		];
	}

	// ------------------------------------------------------------------ //
	// Most commented posts
	// ------------------------------------------------------------------ //

	public function get_most_commented( int $limit = 5 ): array {
		global $wpdb;

		$rows = $this->get_results(
			"SELECT ID, post_title, comment_count
			 FROM {$wpdb->prefix}posts
			 WHERE post_status = 'publish' AND post_type = 'post'
			 ORDER BY comment_count DESC
			 LIMIT %d",
			[ $limit ]
		);

		return [
			'labels' => array_column( $rows, 'post_title' ),
			'data'   => array_map( 'intval', array_column( $rows, 'comment_count' ) ),
			'rows'   => $rows,
		];
	}

	// ------------------------------------------------------------------ //
	// Weekly activity per weekday
	// ------------------------------------------------------------------ //

	public function get_weekly_activity( int $weeks = 8 ): array {
		$cache_key = "sip_wkly_{$weeks}";
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;
		$start = gmdate( 'Y-m-d', (int) strtotime( "-{$weeks} weeks" ) );

		$hist = $this->get_results(
			"SELECT DAYOFWEEK(stat_date) - 1 AS weekday, SUM(visitors) AS total
			 FROM {$wpdb->prefix}sip_daily_stats
			 WHERE stat_date >= %s
			 GROUP BY weekday",
			[ $start ]
		);

		// Add today live.
		$today_wd = (int) gmdate( 'w' );
		$today_v  = $this->get_int(
			"SELECT COUNT(DISTINCT visitor_id) FROM {$wpdb->prefix}sip_events WHERE DATE(created_at) = %s",
			[ gmdate( 'Y-m-d' ) ]
		);

		$days_labels = [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ];
		$totals      = array_fill( 0, 7, 0 );
		foreach ( $hist as $r ) {
			$totals[ (int) $r['weekday'] ] = (int) $r['total'];
		}
		$totals[ $today_wd ] += $today_v;

		$data = [ 'labels' => $days_labels, 'data' => $totals ];
		set_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
		return $data;
	}
}
