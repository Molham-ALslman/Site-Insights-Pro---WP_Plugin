<?php
/**
 * Admin Settings Controller.
 *
 * @package SIP\Admin
 */

declare(strict_types=1);

namespace SIP\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles plugin settings registration and sanitization.
 */
class SettingsController {

	private const OPTION_GROUP = 'sip_settings_group';
	private const OPTION_NAME  = 'sip_settings';

	public function __construct() {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	public function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			self::OPTION_NAME,
			[
				'sanitize_callback' => [ $this, 'sanitize_settings' ],
				'default'           => $this->defaults(),
			]
		);

		add_settings_section(
			'sip_general',
			__( 'General Settings', 'site-insights-pro' ),
			'__return_false',
			self::OPTION_GROUP
		);

		add_settings_field(
			'anonymize_ip',
			__( 'Anonymize IP Addresses', 'site-insights-pro' ),
			[ $this, 'field_checkbox' ],
			self::OPTION_GROUP,
			'sip_general',
			[ 'id' => 'anonymize_ip', 'label' => __( 'Enable for GDPR compliance', 'site-insights-pro' ) ]
		);

		add_settings_field(
			'skip_admin_tracking',
			__( 'Skip Admin Tracking', 'site-insights-pro' ),
			[ $this, 'field_checkbox' ],
			self::OPTION_GROUP,
			'sip_general',
			[ 'id' => 'skip_admin_tracking', 'label' => __( 'Do not track logged-in administrators', 'site-insights-pro' ) ]
		);

		add_settings_field(
			'raw_event_retention_days',
			__( 'Raw Event Retention (days)', 'site-insights-pro' ),
			[ $this, 'field_number' ],
			self::OPTION_GROUP,
			'sip_general',
			[ 'id' => 'raw_event_retention_days', 'min' => 7, 'max' => 365 ]
		);
	}

	public function sanitize_settings( mixed $input ): array {
		$defaults = $this->defaults();
		if ( ! is_array( $input ) ) {
			return $defaults;
		}

		return [
			'anonymize_ip'              => ! empty( $input['anonymize_ip'] ),
			'skip_admin_tracking'       => ! empty( $input['skip_admin_tracking'] ),
			'raw_event_retention_days'  => max( 7, min( 365, absint( $input['raw_event_retention_days'] ?? 90 ) ) ),
		];
	}

	public function field_checkbox( array $args ): void {
		$options = get_option( self::OPTION_NAME, $this->defaults() );
		$id      = esc_attr( $args['id'] );
		$label   = esc_html( $args['label'] );
		$checked = ! empty( $options[ $args['id'] ] ) ? 'checked' : '';
		echo "<label><input type='checkbox' name='sip_settings[{$id}]' id='{$id}' value='1' {$checked}> {$label}</label>"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public function field_number( array $args ): void {
		$options = get_option( self::OPTION_NAME, $this->defaults() );
		$id      = esc_attr( $args['id'] );
		$value   = absint( $options[ $args['id'] ] ?? 90 );
		$min     = absint( $args['min'] ?? 1 );
		$max     = absint( $args['max'] ?? 9999 );
		echo "<input type='number' name='sip_settings[{$id}]' id='{$id}' value='" . esc_attr( $value ) . "' min='{$min}' max='{$max}' class='small-text'>"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private function defaults(): array {
		return [
			'anonymize_ip'             => true,
			'skip_admin_tracking'      => true,
			'raw_event_retention_days' => 90,
		];
	}
}
