<?php
/**
 * Admin Dashboard Controller.
 *
 * @package SIP\Admin
 */

declare(strict_types=1);

namespace SIP\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the admin menu, dashboard page, and enqueues assets.
 */
class DashboardController {

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	/**
	 * Register the admin menu pages.
	 */
	public function register_menu(): void {
		add_menu_page(
			__( 'Site Insights Pro', 'site-insights-pro' ),
			__( 'Site Insights', 'site-insights-pro' ),
			'manage_options',
			'site-insights-pro',
			[ $this, 'render_dashboard' ],
			'dashicons-chart-area',
			3
		);

		add_submenu_page(
			'site-insights-pro',
			__( 'Analytics Dashboard', 'site-insights-pro' ),
			__( 'Dashboard', 'site-insights-pro' ),
			'manage_options',
			'site-insights-pro',
			[ $this, 'render_dashboard' ]
		);

		add_submenu_page(
			'site-insights-pro',
			__( 'Settings', 'site-insights-pro' ),
			__( 'Settings', 'site-insights-pro' ),
			'manage_options',
			'site-insights-pro-settings',
			[ $this, 'render_settings' ]
		);
	}

	/**
	 * Enqueue dashboard assets only on our own pages.
	 */
	public function enqueue_assets( string $hook ): void {
		$our_pages = [
			'toplevel_page_site-insights-pro',
			'site-insights_page_site-insights-pro-settings',
		];

		if ( ! in_array( $hook, $our_pages, true ) ) {
			return;
		}

		// Chart.js.
		wp_enqueue_script(
			'chartjs',
			'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
			[],
			'4.4.0',
			true
		);

		// Plugin dashboard JS — must load BEFORE Alpine initialises.
		wp_enqueue_script(
			'sip-dashboard',
			SIP_PLUGIN_URL . 'assets/js/dashboard.js',
			[ 'chartjs' ],
			SIP_VERSION,
			true  // in footer
		);

		// Alpine.js — depends on sip-dashboard so it loads AFTER it,
		// giving alpine:init time to register sipDashboard().
		wp_enqueue_script(
			'alpinejs',
			'https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js',
			[ 'sip-dashboard' ],
			'3.13.5',
			true  // in footer, NO defer
		);

		wp_localize_script( 'sip-dashboard', 'sipAdmin', [
			'apiBase' => esc_url_raw( rest_url( 'sip/v1' ) ),
			'nonce'   => wp_create_nonce( 'wp_rest' ),
			'i18n'    => [
				'visitors' => __( 'Visitors', 'site-insights-pro' ),
				'pageViews'=> __( 'Page Views', 'site-insights-pro' ),
				'devices'  => __( 'Devices', 'site-insights-pro' ),
				'browsers' => __( 'Browsers', 'site-insights-pro' ),
				'noData'   => __( 'No data available', 'site-insights-pro' ),
				'unique'   => __( 'Unique', 'site-insights-pro' ),
				'newUsers' => __( 'New Users', 'site-insights-pro' ),
				'days'     => [
					__( 'Sun', 'site-insights-pro' ),
					__( 'Mon', 'site-insights-pro' ),
					__( 'Tue', 'site-insights-pro' ),
					__( 'Wed', 'site-insights-pro' ),
					__( 'Thu', 'site-insights-pro' ),
					__( 'Fri', 'site-insights-pro' ),
					__( 'Sat', 'site-insights-pro' ),
				],
			],
		] );

		// Load JS translations (JSON file in /languages/).
		wp_set_script_translations(
			'sip-dashboard',
			'site-insights-pro',
			SIP_PLUGIN_DIR . 'languages'
		);

		// Plugin dashboard CSS.
		wp_enqueue_style(
			'sip-dashboard',
			SIP_PLUGIN_URL . 'assets/css/dashboard.css',
			[],
			SIP_VERSION
		);
	}

	/**
	 * Render the main dashboard page.
	 */
	public function render_dashboard(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'site-insights-pro' ) );
		}

		$template = SIP_PLUGIN_DIR . 'templates/admin/dashboard.php';
		if ( file_exists( $template ) ) {
			include $template;
		}
	}

	/**
	 * Render the settings page.
	 */
	public function render_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'site-insights-pro' ) );
		}

		$template = SIP_PLUGIN_DIR . 'templates/admin/settings.php';
		if ( file_exists( $template ) ) {
			include $template;
		}
	}
}
