<?php
/**
 * Frontend Shortcode: [site_insights_dashboard]
 *
 * @package SIP\Shortcodes
 */

declare(strict_types=1);

namespace SIP\Shortcodes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class InsightsDashboard {

	public function __construct() {
		add_shortcode( 'site_insights_dashboard', [ $this, 'render' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_assets' ] );
	}

	public function maybe_enqueue_assets(): void {
		global $post;
		if ( ! $post || ! has_shortcode( $post->post_content, 'site_insights_dashboard' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$this->enqueue_assets();
	}

	private function enqueue_assets(): void {
		// Chart.js
		wp_enqueue_script(
			'chartjs',
			'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
			[],
			'4.4.0',
			true
		);

		// Plugin dashboard JS — must load BEFORE Alpine.
		wp_enqueue_script(
			'sip-dashboard',
			SIP_PLUGIN_URL . 'assets/js/dashboard.js',
			[ 'chartjs' ],
			SIP_VERSION,
			true
		);

		// ── نفس بيانات الترجمة الموجودة في Admin ──
		wp_localize_script( 'sip-dashboard', 'sipAdmin', [
			'apiBase' => esc_url_raw( rest_url( 'sip/v1' ) ),
			'nonce'   => wp_create_nonce( 'wp_rest' ),
			'i18n'    => [
				'visitors' => __( 'Visitors', 'site-insights-pro' ),
				'pageViews'=> __( 'Page Views', 'site-insights-pro' ),
				'devices'  => __( 'Devices', 'site-insights-pro' ),
				'browsers' => __( 'Browsers', 'site-insights-pro' ),
				'noData'   => __( 'No data available', 'site-insights-pro' ),
				'unique'   => __( 'Unique', 'site-insights-pro' ),
				'newUsers' => __( 'New Users', 'site-insights-pro' ),
				'days'     => [
					__( 'Sun', 'site-insights-pro' ),
					__( 'Mon', 'site-insights-pro' ),
					__( 'Tue', 'site-insights-pro' ),
					__( 'Wed', 'site-insights-pro' ),
					__( 'Thu', 'site-insights-pro' ),
					__( 'Fri', 'site-insights-pro' ),
					__( 'Sat', 'site-insights-pro' ),
				],
			],
		] );

		// ── تحميل ترجمة JavaScript من ملف JSON ──
		wp_set_script_translations(
			'sip-dashboard',
			'site-insights-pro',
			SIP_PLUGIN_DIR . 'languages'
		);

		// Alpine.js — بعد sip-dashboard حتى يعمل alpine:init بشكل صحيح
		wp_enqueue_script(
			'alpinejs',
			'https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js',
			[ 'sip-dashboard' ],
			'3.13.5',
			true
		);

		// CSS
		wp_enqueue_style(
			'sip-dashboard',
			SIP_PLUGIN_URL . 'assets/css/dashboard.css',
			[],
			SIP_VERSION
		);
	}

	public function render( array $atts ): string {
		$atts = shortcode_atts(
			[
				'capability' => 'manage_options',
				'theme'      => 'light',
			],
			$atts,
			'site_insights_dashboard'
		);

		$capability = sanitize_text_field( $atts['capability'] );

		if ( ! current_user_can( $capability ) ) {
			return '<p class="sip-no-access">'
				. esc_html__( 'You do not have permission to view analytics.', 'site-insights-pro' )
				. '</p>';
		}

		// تحميل الأصول حتى عند استخدام الـ shortcode في widget أو page builder
		$this->enqueue_assets();

		ob_start();
		$theme    = in_array( $atts['theme'], [ 'light', 'dark' ], true ) ? $atts['theme'] : 'light';
		$template = SIP_PLUGIN_DIR . 'templates/frontend/dashboard.php';
		if ( file_exists( $template ) ) {
			include $template;
		}
		return ob_get_clean() ?: '';
	}
}
