<?php
/**
 * Database Installer & Migrator.
 *
 * @package SIP\Database
 */

declare(strict_types=1);

namespace SIP\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates and migrates all custom database tables.
 */
class Installer {

	/**
	 * Run installation / upgrade.
	 */
	public static function install(): void {
		global $wpdb;

		$installed_version = get_option( 'sip_db_version', '0.0.0' );

		if ( version_compare( $installed_version, SIP_DB_VERSION, '>=' ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		// ------------------------------------------------------------------ //
		// Table: sip_events — raw page-view / session events.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_events (
			id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			session_id  CHAR(36)            NOT NULL,
			visitor_id  CHAR(36)            NOT NULL,
			user_id     BIGINT(20) UNSIGNED          DEFAULT NULL,
			object_id   BIGINT(20) UNSIGNED          DEFAULT NULL,
			object_type VARCHAR(32)                  DEFAULT NULL,
			url         VARCHAR(2048)       NOT NULL,
			referrer    VARCHAR(2048)                DEFAULT NULL,
			ip_hash     VARCHAR(64)                  DEFAULT NULL,
			country     CHAR(2)                      DEFAULT NULL,
			city        VARCHAR(128)                 DEFAULT NULL,
			device_type VARCHAR(16)                  DEFAULT NULL,
			os          VARCHAR(64)                  DEFAULT NULL,
			browser     VARCHAR(64)                  DEFAULT NULL,
			created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY idx_session    (session_id),
			KEY idx_visitor    (visitor_id),
			KEY idx_created_at (created_at),
			KEY idx_country    (country),
			KEY idx_object     (object_id, object_type)
		) $charset_collate;" );

		// ------------------------------------------------------------------ //
		// Table: sip_daily_stats — pre-aggregated daily summaries.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_daily_stats (
			id              BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			stat_date       DATE                NOT NULL,
			visitors        BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			unique_visitors BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			sessions        BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			page_views      BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			new_users       INT(11) UNSIGNED    NOT NULL DEFAULT 0,
			total_duration  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			UNIQUE KEY idx_date (stat_date)
		) $charset_collate;" );

		// ------------------------------------------------------------------ //
		// Table: sip_page_stats — per-page daily aggregates.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_page_stats (
			id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			stat_date  DATE                NOT NULL,
			object_id  BIGINT(20) UNSIGNED NOT NULL,
			url        VARCHAR(2048)       NOT NULL,
			title      VARCHAR(512)                 DEFAULT NULL,
			views      BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY idx_date_object (stat_date, object_id),
			KEY idx_views       (views)
		) $charset_collate;" );

		// ------------------------------------------------------------------ //
		// Table: sip_geo_stats — country/city daily aggregates.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_geo_stats (
			id        BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			stat_date DATE                NOT NULL,
			country   CHAR(2)             NOT NULL,
			city      VARCHAR(128)                 DEFAULT '',
			visitors  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY idx_date_country (stat_date, country)
		) $charset_collate;" );

		// ------------------------------------------------------------------ //
		// Table: sip_device_stats — device/browser daily aggregates.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_device_stats (
			id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			stat_date   DATE                NOT NULL,
			device_type VARCHAR(16)         NOT NULL DEFAULT 'desktop',
			os          VARCHAR(64)         NOT NULL DEFAULT '',
			browser     VARCHAR(64)         NOT NULL DEFAULT '',
			visitors    BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY idx_date (stat_date)
		) $charset_collate;" );

		// ------------------------------------------------------------------ //
		// Table: sip_hourly_stats — hourly traffic data.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_hourly_stats (
			id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			stat_date  DATE                NOT NULL,
			hour       TINYINT(2) UNSIGNED NOT NULL,
			page_views BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			UNIQUE KEY idx_date_hour (stat_date, hour)
		) $charset_collate;" );

		// ------------------------------------------------------------------ //
		// Table: sip_rate_limits — rate limiting for tracking endpoint.
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}sip_rate_limits (
			ip_hash    VARCHAR(64)         NOT NULL,
			requests   SMALLINT UNSIGNED   NOT NULL DEFAULT 1,
			window_end DATETIME            NOT NULL,
			PRIMARY KEY (ip_hash)
		) $charset_collate;" );

		update_option( 'sip_db_version', SIP_DB_VERSION );
	}

	/**
	 * Drop all plugin tables (used only on uninstall.php).
	 */
	public static function uninstall(): void {
		global $wpdb;

		$tables = [
			'sip_events',
			'sip_daily_stats',
			'sip_page_stats',
			'sip_geo_stats',
			'sip_device_stats',
			'sip_hourly_stats',
			'sip_rate_limits',
		];

		foreach ( $tables as $table ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" );
		}

		delete_option( 'sip_db_version' );
		delete_option( 'sip_settings' );
	}
}
