/**
 * Site Insights Pro — Async Page Tracker
 * Fires a deferred, non-blocking beacon to the REST tracking endpoint.
 * Generates stable visitor/session IDs stored in sessionStorage / localStorage.
 */

( function () {
  'use strict';

  if ( typeof sipTracker === 'undefined' ) return;

  // ── ID helpers ─────────────────────────────────────────────────────────────

  function uuid() {
    return ( [1e7] + -1e3 + -4e3 + -8e3 + -1e11 ).replace( /[018]/g, c =>
      ( c ^ crypto.getRandomValues( new Uint8Array(1) )[0] & 15 >> c / 4 ).toString(16)
    );
  }

  function getOrCreate( storage, key ) {
    try {
      let id = storage.getItem( key );
      if ( ! id ) {
        id = uuid();
        storage.setItem( key, id );
      }
      return id;
    } catch {
      return uuid();
    }
  }

  const visitorId = getOrCreate( localStorage, 'sip_vid' );
  const sessionId = getOrCreate( sessionStorage, 'sip_sid' );

  // ── Send beacon ────────────────────────────────────────────────────────────

  function sendBeacon() {
    const body = JSON.stringify( {
      url:        window.location.href,
      referrer:   document.referrer || '',
      session_id: sessionId,
      visitor_id: visitorId,
      object_id:  sipTracker.objectId || 0,
      post_type:  sipTracker.postType || '',
    } );

    // Prefer sendBeacon for fire-and-forget; fall back to fetch.
    if ( navigator.sendBeacon ) {
      const blob = new Blob( [body], { type: 'application/json' } );
      // sendBeacon doesn't support custom headers, so use fetch fallback
      // for nonce (needed for REST authentication).
    }

    fetch( sipTracker.endpoint, {
      method:      'POST',
      headers: {
        'Content-Type':  'application/json',
        'X-WP-Nonce':    sipTracker.nonce,
      },
      body,
      keepalive: true,        // survive page unload
      credentials: 'same-origin',
    } ).catch( () => {} );    // silently ignore errors
  }

  // ── Fire after page is interactive ────────────────────────────────────────

  if ( document.readyState === 'complete' || document.readyState === 'interactive' ) {
    setTimeout( sendBeacon, 100 );
  } else {
    window.addEventListener( 'load', () => setTimeout( sendBeacon, 100 ) );
  }

}() );
