/**
 * Site Insights Pro — Dashboard JS
 * Auto-detects page language from <html lang> attribute.
 * Works for both admin dashboard and frontend shortcode.
 */

/* global Chart, sipAdmin */
'use strict';

// ── Language Detection ───────────────────────────────────────────────────────
// Priority: WordPress i18n (PHP) → <html lang> → browser lang → fallback EN
const SIP_LANG = (function () {
	// 1. If WordPress already sent translated strings via wp_localize_script, use them.
	if ( window.sipAdmin && window.sipAdmin.i18n && window.sipAdmin.i18n.visitors !== 'Visitors' ) {
		return 'wp'; // already translated by PHP
	}

	// 2. Read <html lang="ar"> or <html lang="ar-SA">
	const htmlLang = document.documentElement.lang || '';
	const lang     = htmlLang.toLowerCase().split('-')[0]; // "ar-SA" → "ar"

	// 3. Fallback to browser language
	const browserLang = ( navigator.language || navigator.userLanguage || '' ).toLowerCase().split('-')[0];

	return lang || browserLang || 'en';
}() );

// ── Translation Dictionary ───────────────────────────────────────────────────
const SIP_TRANSLATIONS = {
	ar: {
		visitors      : 'الزوار',
		unique        : 'فريد',
		pageViews     : 'مشاهدات الصفحة',
		devices       : 'الأجهزة',
		browsers      : 'المتصفحات',
		newUsers      : 'مستخدمون جدد',
		views         : 'مشاهدات',
		comments      : 'تعليقات',
		noData        : 'لا توجد بيانات متاحة',
		lastNDays     : 'آخر {n} يوماً',
		days          : [ 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت' ],
		// KPI labels
		todayVisitors : 'زوار اليوم',
		pageViewsToday: 'مشاهدات اليوم',
		totalSessions : 'إجمالي الجلسات',
		avgDuration   : 'متوسط مدة الجلسة',
		totalUsers    : 'إجمالي المستخدمين',
		totalComments : 'إجمالي التعليقات',
		// Chart titles
		visitorTrend  : 'اتجاه الزيارات',
		topPages      : 'أكثر الصفحات زيارة',
		weeklyActivity: 'النشاط حسب اليوم',
		userGrowth    : 'نمو المستخدمين',
		peakHours     : 'ساعات الذروة',
		topCountries  : 'أكثر الدول زيارة',
		mostCommented : 'أكثر المنشورات تعليقاً',
		noGeoData     : 'لا توجد بيانات جغرافية بعد.',
		// Period selector
		last7         : 'آخر 7 أيام',
		last30        : 'آخر 30 يوماً',
		last90        : 'آخر 90 يوماً',
		lastYear      : 'السنة الماضية',
		// Strip
		newToday      : 'جديد اليوم',
		newWeek       : 'جديد هذا الأسبوع',
		newMonth      : 'جديد هذا الشهر',
		weeklyVis     : 'الزوار الأسبوعيون',
		monthlyVis    : 'الزوار الشهريون',
		avgPages      : 'متوسط الصفحات/جلسة',
		refresh       : 'تحديث',
	},
	fr: {
		visitors      : 'Visiteurs',
		unique        : 'Uniques',
		pageViews     : 'Pages vues',
		devices       : 'Appareils',
		browsers      : 'Navigateurs',
		newUsers      : 'Nouveaux utilisateurs',
		views         : 'Vues',
		comments      : 'Commentaires',
		noData        : 'Aucune donnée disponible',
		days          : [ 'Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam' ],
		visitorTrend  : 'Tendance des visiteurs',
		topPages      : 'Pages populaires',
		weeklyActivity: 'Activité hebdomadaire',
		userGrowth    : 'Croissance des utilisateurs',
		peakHours     : 'Heures de pointe',
		topCountries  : 'Pays principaux',
		mostCommented : 'Articles les plus commentés',
		noGeoData     : 'Pas encore de données géographiques.',
		last7         : '7 derniers jours',
		last30        : '30 derniers jours',
		last90        : '90 derniers jours',
		lastYear      : 'Dernière année',
		newToday      : 'Nouveaux aujourd\'hui',
		newWeek       : 'Nouveaux cette semaine',
		newMonth      : 'Nouveaux ce mois',
		weeklyVis     : 'Visiteurs hebdo',
		monthlyVis    : 'Visiteurs mensuels',
		avgPages      : 'Pages moy./session',
		refresh       : 'Actualiser',
	},
	de: {
		visitors      : 'Besucher',
		unique        : 'Eindeutig',
		pageViews     : 'Seitenaufrufe',
		devices       : 'Geräte',
		browsers      : 'Browser',
		newUsers      : 'Neue Benutzer',
		views         : 'Aufrufe',
		comments      : 'Kommentare',
		noData        : 'Keine Daten verfügbar',
		days          : [ 'So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa' ],
		visitorTrend  : 'Besuchertrend',
		topPages      : 'Top-Seiten',
		weeklyActivity: 'Wöchentliche Aktivität',
		userGrowth    : 'Benutzerwachstum',
		peakHours     : 'Stoßzeiten',
		topCountries  : 'Top-Länder',
		mostCommented : 'Meistkommentierte Beiträge',
		noGeoData     : 'Noch keine geografischen Daten.',
		last7         : 'Letzte 7 Tage',
		last30        : 'Letzte 30 Tage',
		last90        : 'Letzte 90 Tage',
		lastYear      : 'Letztes Jahr',
		newToday      : 'Neu heute',
		newWeek       : 'Neu diese Woche',
		newMonth      : 'Neu diesen Monat',
		weeklyVis     : 'Wöchentliche Besucher',
		monthlyVis    : 'Monatliche Besucher',
		avgPages      : 'Ø Seiten/Sitzung',
		refresh       : 'Aktualisieren',
	},
	es: {
		visitors      : 'Visitantes',
		unique        : 'Únicos',
		pageViews     : 'Vistas de página',
		devices       : 'Dispositivos',
		browsers      : 'Navegadores',
		newUsers      : 'Nuevos usuarios',
		views         : 'Vistas',
		comments      : 'Comentarios',
		noData        : 'No hay datos disponibles',
		days          : [ 'Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb' ],
		visitorTrend  : 'Tendencia de visitantes',
		topPages      : 'Páginas populares',
		weeklyActivity: 'Actividad semanal',
		userGrowth    : 'Crecimiento de usuarios',
		peakHours     : 'Horas pico',
		topCountries  : 'Principales países',
		mostCommented : 'Posts más comentados',
		noGeoData     : 'Aún no hay datos geográficos.',
		last7         : 'Últimos 7 días',
		last30        : 'Últimos 30 días',
		last90        : 'Últimos 90 días',
		lastYear      : 'Último año',
		newToday      : 'Nuevos hoy',
		newWeek       : 'Nuevos esta semana',
		newMonth      : 'Nuevos este mes',
		weeklyVis     : 'Visitantes semanales',
		monthlyVis    : 'Visitantes mensuales',
		avgPages      : 'Páginas prom./sesión',
		refresh       : 'Actualizar',
	},
	// English fallback
	en: {
		visitors      : 'Visitors',
		unique        : 'Unique',
		pageViews     : 'Page Views',
		devices       : 'Devices',
		browsers      : 'Browsers',
		newUsers      : 'New Users',
		views         : 'Views',
		comments      : 'Comments',
		noData        : 'No data available',
		days          : [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ],
		visitorTrend  : 'Visitor Trend',
		topPages      : 'Top Pages',
		weeklyActivity: 'Weekday Activity',
		userGrowth    : 'User Growth',
		peakHours     : 'Peak Traffic Hours',
		topCountries  : 'Top Countries',
		mostCommented : 'Most Commented Posts',
		noGeoData     : 'No geographic data yet.',
		last7         : 'Last 7 days',
		last30        : 'Last 30 days',
		last90        : 'Last 90 days',
		lastYear      : 'Last year',
		newToday      : 'New Today',
		newWeek       : 'New This Week',
		newMonth      : 'New This Month',
		weeklyVis     : 'Weekly Visitors',
		monthlyVis    : 'Monthly Visitors',
		avgPages      : 'Avg Pages/Session',
		refresh       : 'Refresh',
	},
};

/**
 * Get translated string.
 * Priority: WordPress PHP i18n → JS dictionary → English fallback
 */
function t( key ) {
	// WordPress PHP translation (via wp_localize_script i18n object)
	if ( window.sipAdmin && window.sipAdmin.i18n && window.sipAdmin.i18n[ key ] ) {
		return window.sipAdmin.i18n[ key ];
	}
	// JS dictionary by detected language
	const dict = SIP_TRANSLATIONS[ SIP_LANG ] || SIP_TRANSLATIONS.en;
	return dict[ key ] || SIP_TRANSLATIONS.en[ key ] || key;
}

/**
 * Get days array in correct language.
 */
function tDays() {
	if ( window.sipAdmin && window.sipAdmin.i18n && window.sipAdmin.i18n.days ) {
		return window.sipAdmin.i18n.days;
	}
	const dict = SIP_TRANSLATIONS[ SIP_LANG ] || SIP_TRANSLATIONS.en;
	return dict.days || SIP_TRANSLATIONS.en.days;
}

/**
 * Is the current language RTL?
 */
const SIP_IS_RTL = [ 'ar', 'he', 'fa', 'ur' ].includes( SIP_LANG );

// ── Apply RTL class automatically ────────────────────────────────────────────
if ( SIP_IS_RTL ) {
	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '.sip-wrap' ).forEach( el => {
			el.setAttribute( 'dir', 'rtl' );
		} );
	} );
}

// ── Translate static HTML elements (labels/titles rendered by PHP) ────────────
function sipTranslateDOM() {
	if ( SIP_LANG === 'en' || SIP_LANG === 'wp' ) return;

	const map = {
		// data-sip-i18n attribute → translation key
	};

	// Translate elements with data-sip-i18n attribute
	document.querySelectorAll( '[data-sip-i18n]' ).forEach( el => {
		const key = el.getAttribute( 'data-sip-i18n' );
		const translated = t( key );
		if ( translated ) el.textContent = translated;
	} );
}

// ── Palette ──────────────────────────────────────────────────────────────────
const SIP_COLORS = [
	'#6366f1','#22d3ee','#10b981','#f59e0b',
	'#f43f5e','#a855f7','#14b8a6','#fb923c',
];

function sipAlpha( hex, alpha ) {
	const r = parseInt( hex.slice(1,3), 16 );
	const g = parseInt( hex.slice(3,5), 16 );
	const b = parseInt( hex.slice(5,7), 16 );
	return `rgba(${r},${g},${b},${alpha})`;
}

// ── Canvas resolver (admin vs frontend) ──────────────────────────────────────
function sipCtx( id ) {
	return document.getElementById( 'sip-fe-' + id ) || document.getElementById( id );
}

// ── Theme colors ─────────────────────────────────────────────────────────────
function getTheme() {
	const s = getComputedStyle( document.documentElement );
	return {
		text  : s.getPropertyValue('--sip-text').trim()       || '#1e293b',
		muted : s.getPropertyValue('--sip-text-muted').trim() || '#64748b',
		border: s.getPropertyValue('--sip-border').trim()     || '#e2e8f0',
	};
}

Chart.defaults.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
Chart.defaults.font.size   = 12;

// ── API helper ────────────────────────────────────────────────────────────────
async function sipFetch( path, params = {} ) {
	const url = new URL( sipAdmin.apiBase + path );
	Object.entries( params ).forEach( ([k,v]) => url.searchParams.set(k,v) );
	const resp = await fetch( url.toString(), {
		headers    : { 'X-WP-Nonce': sipAdmin.nonce },
		credentials: 'same-origin',
	} );
	if ( ! resp.ok ) throw new Error( `SIP API error: ${resp.status}` );
	return resp.json();
}

// ── Chart registry ────────────────────────────────────────────────────────────
const _charts = {};
function destroyChart( id ) {
	if ( _charts[id] ) { _charts[id].destroy(); delete _charts[id]; }
}

// ── Chart builders ────────────────────────────────────────────────────────────

function buildVisitorChart( data ) {
	destroyChart('visitors');
	const ctx = sipCtx('chartVisitors');
	if ( ! ctx ) return;
	const { muted, border } = getTheme();
	_charts.visitors = new Chart( ctx, {
		type: 'line',
		data: {
			labels  : data.labels,
			datasets: [
				{
					label           : t('visitors'),
					data            : data.visitors,
					borderColor     : '#6366f1',
					backgroundColor : sipAlpha('#6366f1', .12),
					fill            : true,
					tension         : .4,
					pointRadius     : 3,
					pointHoverRadius: 6,
				},
				{
					label      : t('unique'),
					data       : data.unique,
					borderColor: '#22d3ee',
					tension    : .4,
					borderDash : [4,4],
					pointRadius: 2,
				},
			],
		},
		options: {
			responsive : true,
			interaction: { mode: 'index', intersect: false },
			plugins    : { legend: { labels: { color: muted, boxWidth: 12 } } },
			scales     : {
				x: { grid: { color: border }, ticks: { color: muted, maxTicksLimit: 8 } },
				y: { grid: { color: border }, ticks: { color: muted } },
			},
		},
	} );
}

function buildDevicesChart( data ) {
	destroyChart('devices');
	const ctx = sipCtx('chartDevices');
	if ( ! ctx ) return;
	const { muted } = getTheme();
	_charts.devices = new Chart( ctx, {
		type: 'doughnut',
		data: {
			labels  : data.labels,
			datasets: [{ data: data.data, backgroundColor: SIP_COLORS, borderWidth: 0 }],
		},
		options: {
			cutout : '68%',
			plugins: { legend: { position: 'bottom', labels: { color: muted, padding: 12, boxWidth: 10 } } },
		},
	} );
}

function buildPagesChart( data ) {
	destroyChart('pages');
	const ctx = sipCtx('chartPages');
	if ( ! ctx ) return;
	const { muted, border } = getTheme();
	const labels = data.labels.map( l => l.length > 35 ? l.slice(0,33)+'…' : l );
	_charts.pages = new Chart( ctx, {
		type: 'bar',
		data: {
			labels,
			datasets: [{ label: t('views'), data: data.views, backgroundColor: SIP_COLORS[0], borderRadius: 4 }],
		},
		options: {
			indexAxis: 'y',
			responsive: true,
			plugins   : { legend: { display: false } },
			scales    : {
				x: { grid: { color: border }, ticks: { color: muted } },
				y: { grid: { display: false }, ticks: { color: muted } },
			},
		},
	} );
}

function buildBrowsersChart( data ) {
	destroyChart('browsers');
	const ctx = sipCtx('chartBrowsers');
	if ( ! ctx ) return;
	const { muted } = getTheme();
	_charts.browsers = new Chart( ctx, {
		type: 'pie',
		data: {
			labels  : data.labels,
			datasets: [{ data: data.data, backgroundColor: SIP_COLORS, borderWidth: 0 }],
		},
		options: {
			plugins: { legend: { position: 'bottom', labels: { color: muted, padding: 10, boxWidth: 10 } } },
		},
	} );
}

function buildWeeklyChart( data ) {
	destroyChart('weekly');
	const ctx = sipCtx('chartWeekly');
	if ( ! ctx ) return;
	const { muted, border } = getTheme();
	const days = tDays();
	_charts.weekly = new Chart( ctx, {
		type: 'bar',
		data: {
			labels  : days,
			datasets: [{
				label          : t('visitors'),
				data           : data.data,
				backgroundColor: data.data.map( (_, i) => i === new Date().getDay() ? '#f59e0b' : '#6366f1' ),
				borderRadius   : 4,
			}],
		},
		options: {
			responsive: true,
			plugins   : { legend: { display: false } },
			scales    : {
				x: { grid: { display: false }, ticks: { color: muted } },
				y: { grid: { color: border },  ticks: { color: muted } },
			},
		},
	} );
}

function buildUserChart( data ) {
	destroyChart('users');
	const ctx = sipCtx('chartUsers');
	if ( ! ctx ) return;
	const { muted, border } = getTheme();
	_charts.users = new Chart( ctx, {
		type: 'line',
		data: {
			labels  : data.labels,
			datasets: [{
				label          : t('newUsers'),
				data           : data.data,
				borderColor    : '#10b981',
				backgroundColor: sipAlpha('#10b981', .12),
				fill           : true,
				tension        : .4,
				pointRadius    : 3,
			}],
		},
		options: {
			responsive: true,
			plugins   : { legend: { display: false } },
			scales    : {
				x: { grid: { color: border }, ticks: { color: muted, maxTicksLimit: 8 } },
				y: { grid: { color: border }, ticks: { color: muted } },
			},
		},
	} );
}

function buildCommentsChart( data ) {
	destroyChart('comments');
	const ctx = sipCtx('chartComments');
	if ( ! ctx ) return;
	const { muted, border } = getTheme();
	_charts.comments = new Chart( ctx, {
		type: 'bar',
		data: {
			labels  : data.labels,
			datasets: [{ label: t('comments'), data: data.data, backgroundColor: '#a855f7', borderRadius: 4 }],
		},
		options: {
			indexAxis: 'y',
			responsive: true,
			plugins   : { legend: { display: false } },
			scales    : {
				x: { grid: { color: border }, ticks: { color: muted } },
				y: { grid: { display: false }, ticks: { color: muted } },
			},
		},
	} );
}

// ── Heatmap ───────────────────────────────────────────────────────────────────
function buildHeatmapHtml( matrix ) {
	const days   = tDays();
	const max    = Math.max( ...matrix.flat(), 1 );
	const colors = [
		'var(--sip-border)',
		'#312e81','#3730a3','#4338ca','#4f46e5',
		'#6366f1','#818cf8','#a5b4fc','#c7d2fe','#e0e7ff',
	];

	let html = '';
	// Hour headers
	html += '<div class="sip-heatmap__label"></div>';
	for ( let h = 0; h < 24; h++ ) {
		html += `<div class="sip-heatmap__hour-header">${h}</div>`;
	}
	// Rows
	matrix.forEach( ( row, di ) => {
		html += `<div class="sip-heatmap__label">${days[di]}</div>`;
		row.forEach( val => {
			const idx = Math.round( (val / max) * 9 );
			html += `<div class="sip-heatmap__cell" style="background:${colors[idx]}" title="${val}"></div>`;
		} );
	} );
	return html;
}

// ── Alpine.js Component ───────────────────────────────────────────────────────
function sipDashboard() {
	return {
		loading    : false,
		period     : 30,
		summary    : {},
		countries  : [],
		heatmapHtml: '',

		// ── Translation — sipLabel is a data property so Alpine finds it immediately ──
		// Usage in template: x-text="sipLabel('key')"
		sipLabel( key ) { return t( key ); },

		async init() {
			// Apply DOM translations for PHP-rendered text
			sipTranslateDOM();
			// Apply RTL dir attribute
			if ( SIP_IS_RTL ) {
				this.$el.setAttribute( 'dir', 'rtl' );
			}
			await this.loadAll();
		},

		async loadAll() {
			this.loading = true;
			try {
				await Promise.all([
					this.loadSummary(),
					this.loadVisitorChart(),
					this.loadDevicesChart(),
					this.loadPagesChart(),
					this.loadBrowsersChart(),
					this.loadWeeklyChart(),
					this.loadUserChart(),
					this.loadHeatmap(),
					this.loadCountries(),
					this.loadCommentsChart(),
				]);
			} catch ( err ) {
				console.error( 'SIP Dashboard error:', err );
			} finally {
				this.loading = false;
			}
		},

		async loadSummary()       { this.summary    = await sipFetch('/summary'); },
		async loadVisitorChart()  { buildVisitorChart(  await sipFetch('/chart/visitors', { days: this.period }) ); },
		async loadDevicesChart()  { buildDevicesChart(  await sipFetch('/chart/devices',  { days: this.period }) ); },
		async loadPagesChart()    { buildPagesChart(    await sipFetch('/chart/pages',    { days: this.period, limit: 10 }) ); },
		async loadBrowsersChart() { buildBrowsersChart( await sipFetch('/chart/browsers', { days: this.period }) ); },
		async loadWeeklyChart()   { buildWeeklyChart(   await sipFetch('/chart/weekly') ); },
		async loadUserChart()     { buildUserChart(     await sipFetch('/users/growth',   { days: this.period }) ); },
		async loadCommentsChart() { buildCommentsChart( await sipFetch('/content/comments') ); },

		async loadHeatmap() {
			const matrix     = await sipFetch('/chart/heatmap', { days: this.period });
			this.heatmapHtml = buildHeatmapHtml( matrix );
		},

		async loadCountries() {
			this.countries = await sipFetch('/geo/countries', { days: this.period, limit: 10 });
		},

		// ── Formatters ──────────────────────────────────────────────────────
		fmt( val ) {
			if ( val == null || val === '' ) return '—';
			// Use locale-aware number formatting based on detected language
			const locale = SIP_LANG !== 'en' && SIP_LANG !== 'wp'
				? document.documentElement.lang || 'en'
				: 'en';
			try {
				return Number( val ).toLocaleString( locale );
			} catch {
				return Number( val ).toLocaleString();
			}
		},

		fmtDuration( secs ) {
			if ( ! secs ) return '—';
			const m = Math.floor( secs / 60 );
			const s = secs % 60;
			return m > 0 ? `${m}m ${s}s` : `${s}s`;
		},

		countryFlag( iso2 ) {
			if ( ! iso2 || iso2.length !== 2 ) return '🌐';
			return String.fromCodePoint(
				...iso2.toUpperCase().split('').map( c => 127397 + c.charCodeAt(0) )
			);
		},


	};
}

// ── Expose t() globally so Alpine templates can call it directly ─────────────
window.sipT = t;
window.sipTDays = tDays;

// ── Expose translation function globally for Alpine templates ─────────────────
// x-text="sipLabel('key')" works before Alpine initialises the component.
window.sipLabel = t;

// ── Register with Alpine ──────────────────────────────────────────────────────
document.addEventListener( 'alpine:init', function () {
	// Register the dashboard component
	Alpine.data( 'sipDashboard', sipDashboard );

	// sipLabel is defined as a data property in sipDashboard()
	// so it is accessible via x-text="sipLabel('key')" inside x-data scope.
} );

if ( window.Alpine ) {
	window.Alpine.data( 'sipDashboard', sipDashboard );
}
